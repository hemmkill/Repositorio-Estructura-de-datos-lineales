
# movimientos.py
# Operadores de cambio de estado del cubo (18 movimientos)

from copy import deepcopy

def rotar_horario(cara):
    return [cara[6], cara[3], cara[0], 
            cara[7], cara[4], cara[1], 
            cara[8], cara[5], cara[2]]

def rotar_antihorario(cara):
    return [cara[2], cara[5], cara[8], 
            cara[1], cara[4], cara[7], 
            cara[0], cara[3], cara[6]]


# EJE X (Movimientos Horizontales: X1, X2, X3)


def X_base(cubo, fila_inicio, fila_fin, direccion):
    nuevo = deepcopy(cubo)
    f = cubo["F"][fila_inicio:fila_fin]
    r = cubo["R"][fila_inicio:fila_fin]
    b = cubo["B"][fila_inicio:fila_fin]
    l = cubo["L"][fila_inicio:fila_fin]

    if direccion == "R":
        nuevo["R"][fila_inicio:fila_fin] = f
        nuevo["B"][fila_inicio:fila_fin] = r
        nuevo["L"][fila_inicio:fila_fin] = b
        nuevo["F"][fila_inicio:fila_fin] = l
    else: # "L"
        nuevo["L"][fila_inicio:fila_fin] = f
        nuevo["F"][fila_inicio:fila_fin] = r
        nuevo["R"][fila_inicio:fila_fin] = b
        nuevo["B"][fila_inicio:fila_fin] = l
    return nuevo

def X1R(cubo):
    nuevo = X_base(cubo, 0, 3, "R")
    nuevo["U"] = rotar_antihorario(nuevo["U"])
    return nuevo

def X1L(cubo):
    nuevo = X_base(cubo, 0, 3, "L")
    nuevo["U"] = rotar_horario(nuevo["U"])
    return nuevo

def X2R(cubo): return X_base(cubo, 3, 6, "R")
def X2L(cubo): return X_base(cubo, 3, 6, "L")

def X3R(cubo):
    nuevo = X_base(cubo, 6, 9, "R")
    nuevo["D"] = rotar_horario(nuevo["D"])
    return nuevo

def X3L(cubo):
    nuevo = X_base(cubo, 6, 9, "L")
    nuevo["D"] = rotar_antihorario(nuevo["D"])
    return nuevo


# EJE Y (Movimientos Verticales: Y1, Y2, Y3)


def Y_base(cubo, indices, direccion):
    nuevo = deepcopy(cubo)
    f = [cubo["F"][i] for i in indices]
    u = [cubo["U"][i] for i in indices]
    b = [cubo["B"][i] for i in indices]
    d = [cubo["D"][i] for i in indices]

    if direccion == "U":
        for idx, i in enumerate(indices):
            nuevo["U"][i] = f[idx]
            nuevo["B"][i] = u[idx]
            nuevo["D"][i] = b[idx]
            nuevo["F"][i] = d[idx]
    else: # "D"
        for idx, i in enumerate(indices):
            nuevo["D"][i] = f[idx]
            nuevo["F"][i] = u[idx]
            nuevo["U"][i] = b[idx]
            nuevo["B"][i] = d[idx]
    return nuevo

def Y1U(cubo):
    nuevo = Y_base(cubo, [0, 3, 6], "U")
    nuevo["L"] = rotar_antihorario(nuevo["L"])
    return nuevo

def Y1D(cubo):
    nuevo = Y_base(cubo, [0, 3, 6], "D")
    nuevo["L"] = rotar_horario(nuevo["L"])
    return nuevo

def Y2U(cubo): return Y_base(cubo, [1, 4, 7], "U")
def Y2D(cubo): return Y_base(cubo, [1, 4, 7], "D")

def Y3U(cubo):
    nuevo = Y_base(cubo, [2, 5, 8], "U")
    nuevo["R"] = rotar_horario(nuevo["R"])
    return nuevo

def Y3D(cubo):
    nuevo = Y_base(cubo, [2, 5, 8], "D")
    nuevo["R"] = rotar_antihorario(nuevo["R"])
    return nuevo


# EJE Z (Movimientos de Profundidad: Z1, Z2, Z3)


def Z_base(cubo, i_U, i_R, i_D, i_L, direccion):
    nuevo = deepcopy(cubo)
    u = [cubo["U"][i] for i in i_U]
    r = [cubo["R"][i] for i in i_R]
    d = [cubo["D"][i] for i in i_D]
    l = [cubo["L"][i] for i in i_L]

    if direccion == "R": # Horario (Clockwise)
        for idx in range(3):
            nuevo["R"][i_R[idx]] = u[idx]
            nuevo["D"][i_D[idx]] = r[idx]
            nuevo["L"][i_L[idx]] = d[idx]
            nuevo["U"][i_U[idx]] = l[idx]
    else: # "L" Antihorario
        for idx in range(3):
            nuevo["L"][i_L[idx]] = u[idx]
            nuevo["D"][i_D[idx]] = l[idx]
            nuevo["R"][i_R[idx]] = d[idx]
            nuevo["U"][i_U[idx]] = r[idx]
    return nuevo

def Z1R(cubo):
    nuevo = Z_base(cubo, [6,7,8], [0,3,6], [0,1,2], [2,5,8], "R")
    nuevo["F"] = rotar_horario(nuevo["F"])
    return nuevo

def Z1L(cubo):
    nuevo = Z_base(cubo, [6,7,8], [0,3,6], [0,1,2], [2,5,8], "L")
    nuevo["F"] = rotar_antihorario(nuevo["F"])
    return nuevo

def Z2R(cubo): return Z_base(cubo, [3,4,5], [1,4,7], [3,4,5], [1,4,7], "R")
def Z2L(cubo): return Z_base(cubo, [3,4,5], [1,4,7], [3,4,5], [1,4,7], "L")

def Z3R(cubo):
    nuevo = Z_base(cubo, [0,1,2], [2,5,8], [6,7,8], [0,3,6], "R")
    nuevo["B"] = rotar_antihorario(nuevo["B"]) 
    return nuevo

def Z3L(cubo):
    nuevo = Z_base(cubo, [0,1,2], [2,5,8], [6,7,8], [0,3,6], "L")
    nuevo["B"] = rotar_horario(nuevo["B"])
    return nuevo