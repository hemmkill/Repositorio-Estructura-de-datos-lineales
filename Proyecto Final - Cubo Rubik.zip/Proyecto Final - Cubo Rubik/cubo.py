
# cubo.py
# Representación y estado del cubo Rubik


colores = {
    "W": "⬜", # Blanco
    "Y": "🟨", # Amarillo
    "G": "🟩", # Verde
    "B": "🟦", # Azul
    "O": "🟧", # Naranja
    "R": "🟥"  # Rojo
}

def crear_cubo():
    # El cubo se abstrae como un diccionario con 6 caras.
    # Cada cara es una lista plana de 9 posiciones.
    cubo = {
        "U": ["W"] * 9,   # Arriba (Up)
        "D": ["Y"] * 9,   # Abajo (Down)
        "F": ["G"] * 9,   # Frente (Front)
        "B": ["B"] * 9,   # Atrás (Back)
        "L": ["O"] * 9,   # Izquierda (Left)
        "R": ["R"] * 9    # Derecha (Right)
    }
    return cubo

def mostrar_cubo(cubo):
    # Imprime el cubo de forma visual en la consola
    U, D, F, B, L, R = cubo["U"], cubo["D"], cubo["F"], cubo["B"], cubo["L"], cubo["R"]
    
    U = [colores[x] for x in U]
    D = [colores[x] for x in D]
    F = [colores[x] for x in F]
    B = [colores[x] for x in B]
    L = [colores[x] for x in L]
    R = [colores[x] for x in R]
    print("\n")

    # Cara superior
    for i in range(0, 9, 3):
        print("      ", *U[i:i+3])
    print()

    # Caras del medio (Izquierda, Frente, Derecha, Atrás)
    for i in range(0, 9, 3):
        print(
            *L[i:i+3], " ",
            *F[i:i+3], " ",
            *R[i:i+3], " ",
            *B[i:i+3]
        )
    print()

    # Cara inferior
    for i in range(0, 9, 3):
        print("      ", *D[i:i+3])
    print("\n")

def esta_resuelto(cubo):
    # Verifica si el estado actual es el Estado Final (f)
    # Todos los lados deben tener un solo color.
    for cara in cubo:
        color = cubo[cara][0]
        for cuadro in cubo[cara]:
            if cuadro != color:
                return False
    return True