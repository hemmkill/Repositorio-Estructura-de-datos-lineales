
# bfs.py
# Algoritmo de Búsqueda en Anchura (BFS)

from collections import deque
from cubo import esta_resuelto
import movimientos as mov  # Importamos el módulo completo para mayor limpieza

def bfs(estado_inicial):
    # Estructura Cola (FIFO) para orden de visita
    cola = deque()
    visitados = set()

    cola.append((estado_inicial, []))

    # Lista con las 18 posibles acciones para cada estado
    acciones = [
        ("X1R", mov.X1R), ("X1L", mov.X1L), ("X2R", mov.X2R), ("X2L", mov.X2L), ("X3R", mov.X3R), ("X3L", mov.X3L),
        ("Y1U", mov.Y1U), ("Y1D", mov.Y1D), ("Y2U", mov.Y2U), ("Y2D", mov.Y2D), ("Y3U", mov.Y3U), ("Y3D", mov.Y3D),
        ("Z1R", mov.Z1R), ("Z1L", mov.Z1L), ("Z2R", mov.Z2R), ("Z2L", mov.Z2L), ("Z3R", mov.Z3R), ("Z3L", mov.Z3L)
    ]

    while cola:
        estado_actual, camino = cola.popleft()

        # Si encontramos la solución
        if esta_resuelto(estado_actual):
            return camino

        estado_str = str(estado_actual)

        if estado_str in visitados:
            continue

        visitados.add(estado_str)

        # Expandimos los 18 vecinos (Aristas E)
        for nombre, operacion in acciones:
            nuevo_estado = operacion(estado_actual)
            cola.append((nuevo_estado, camino + [nombre]))

    return None