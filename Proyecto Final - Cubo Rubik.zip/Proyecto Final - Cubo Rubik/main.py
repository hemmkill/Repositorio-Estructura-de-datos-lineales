
# main.py
# Archivo de ejecución del Taller

from cubo import crear_cubo, mostrar_cubo
from bfs import bfs
import movimientos as mov

print("   TALLER: RESOLUCIÓN CUBO RUBIK (BFS)  ")


cubo = crear_cubo()

# 1. Mezclar cubo 
cubo = mov.X1R(cubo)
cubo = mov.Y2U(cubo)
cubo = mov.Z1L(cubo)

print("CUBO MEZCLADO (Estado Inicial s0):")
mostrar_cubo(cubo)

print("Buscando solución utilizando BFS con 18 operadores...")
# 2. Buscar solución
solucion = bfs(cubo)

print("SOLUCIÓN ENCONTRADA (Ruta más corta):")
print(solucion)

# Diccionario para evitar hacer 18 "if/elif"
mapa_movimientos = {
    "X1R": mov.X1R, "X1L": mov.X1L, "X2R": mov.X2R, "X2L": mov.X2L, "X3R": mov.X3R, "X3L": mov.X3L,
    "Y1U": mov.Y1U, "Y1D": mov.Y1D, "Y2U": mov.Y2U, "Y2D": mov.Y2D, "Y3U": mov.Y3U, "Y3D": mov.Y3D,
    "Z1R": mov.Z1R, "Z1L": mov.Z1L, "Z2R": mov.Z2R, "Z2L": mov.Z2L, "Z3R": mov.Z3R, "Z3L": mov.Z3L
}

# 3. Aplicar solución dinámicamente
if solucion:
    for movimiento in solucion:
        cubo = mapa_movimientos[movimiento](cubo)

    print("\nCUBO FINAL (Estado Final f):")
    mostrar_cubo(cubo)
else:
    print("No se encontró solución.")